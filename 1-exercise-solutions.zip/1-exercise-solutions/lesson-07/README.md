# Exercises
![Exercises 7](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/10d9eb95-d0b0-40a1-ba93-29a7e28340f2)
![Exercises 7 2](https://user-images.githubusercontent.com/70604577/229874034-96435582-d769-44ee-ad12-cfd9da855bc1.png)
![Exercises 7 3 (4)](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/0d9813c9-fffc-4254-a973-62a12795fd13)
![Exercises 7 4](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/cd652edb-a11c-4812-96b6-9555fecb3c58)

