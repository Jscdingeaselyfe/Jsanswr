# Exercises
![Exercises 11](https://user-images.githubusercontent.com/70604577/229876018-44b714f3-dacb-4138-a6fe-e6c09ca15f43.png)
![Exercises 11 2](https://user-images.githubusercontent.com/70604577/229876008-56140498-d137-4727-b89d-655e741e0e0f.png)
![Exercises 11 3](https://user-images.githubusercontent.com/70604577/229876010-4542b8a6-822d-40f1-8ffa-39b98358cb8c.png)
![Exercises 11 4](https://user-images.githubusercontent.com/70604577/229876013-abbd7acb-3b3c-49ae-be2a-ed3f65e416cc.png)
![Exercises 11-part-2](https://user-images.githubusercontent.com/70604577/229876062-2422e88d-4d7d-4c26-9255-79e27a983b1f.png)
![Exercises 11-part-2 2](https://user-images.githubusercontent.com/70604577/229876056-6f1c359d-3c75-4cf7-a248-714f1e6ba975.png)
![Exercises 11-part-2 3](https://user-images.githubusercontent.com/70604577/229876059-d0cf6fea-11da-46c7-bcab-eb14f67f5849.png)
![Exercises 11-part-2 4](https://user-images.githubusercontent.com/70604577/229876060-3d90f1c9-f019-4af4-8013-1182c4f221b2.png)
